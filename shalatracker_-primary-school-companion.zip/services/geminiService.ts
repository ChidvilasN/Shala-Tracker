
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export interface AIExplanation {
  explanationEn: string;
  explanationKn: string;
  visualDescription: string;
  activityEn: string;
  activityKn: string;
  videoUrl?: string;
  quiz: { question: string; answer: string }[];
}

export const explainConcept = async (concept: string, standard: string, language: 'en' | 'kn'): Promise<AIExplanation | null> => {
  try {
    // Using gemini-3-pro-preview for high-quality reasoning and Google Search grounding
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Explain the following Karnataka Board textbook concept for a primary school student in ${standard}. 
      Concept: ${concept}. 
      
      Tasks:
      1. Provide a simple bilingual explanation (English and Kannada).
      2. Suggest a classroom activity.
      3. Create a 2-question quiz.
      4. Crucially, find and provide a relevant YouTube video link where this specific concept is explained in Kannada.
      
      Return the results in JSON format.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            explanationEn: { type: Type.STRING },
            explanationKn: { type: Type.STRING },
            visualDescription: { type: Type.STRING },
            activityEn: { type: Type.STRING },
            activityKn: { type: Type.STRING },
            videoUrl: { type: Type.STRING, description: "A valid YouTube URL for a Kannada explanation of this concept" },
            quiz: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  answer: { type: Type.STRING }
                }
              }
            }
          },
          required: ["explanationEn", "explanationKn", "visualDescription", "activityEn", "activityKn", "quiz"]
        }
      }
    });

    const result = JSON.parse(response.text.trim());
    
    // If the model didn't return a videoUrl in the JSON, try to extract it from grounding metadata
    if (!result.videoUrl) {
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const ytChunk = chunks?.find(c => c.web?.uri?.includes('youtube.com') || c.web?.uri?.includes('youtu.be'));
      if (ytChunk) {
        result.videoUrl = ytChunk.web?.uri;
      }
    }

    return result;
  } catch (error) {
    console.error("AI Explanation failed:", error);
    return null;
  }
};

export const analyzeMeal = async (base64Image: string): Promise<{ mealItem: string, calories: number } | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Image
          }
        },
        {
          text: "Identify the primary meal item in this photo of a primary school mid-day meal in Karnataka, India. Estimate the total calories for a typical child portion. Return JSON with 'mealItem' and 'calories'."
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mealItem: { type: Type.STRING },
            calories: { type: Type.NUMBER }
          }
        }
      }
    });
    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Meal analysis failed:", error);
    return null;
  }
};

export const generateEducationalVideo = async (prompt: string): Promise<string | null> => {
  try {
    const aiWithKey = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    let operation = await aiWithKey.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: `Simple educational 2D animation suitable for primary school children explaining: ${prompt}. Bright colors, clear visuals.`,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await aiWithKey.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (downloadLink) {
      return `${downloadLink}&key=${process.env.API_KEY}`;
    }
    return null;
  } catch (error) {
    console.error("Video generation failed:", error);
    return null;
  }
};
