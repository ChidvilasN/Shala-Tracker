
import React, { useState, useEffect } from 'react';
import { Student, AppView, Language, DailyLog, Assessment, CalendarEvent, AttendanceStatus } from './types';
import { INITIAL_STUDENTS, TRANSLATIONS, INITIAL_EVENTS } from './constants';
import { getFromLocal, saveToLocal } from './utils/db';
import StudentGrid from './components/StudentGrid';
import CalendarModule from './components/CalendarModule';
import StudentProfile from './components/StudentProfile';
import AITutorModule from './components/AITutorModule';
import BulkAttendance from './components/BulkAttendance';
import BulkMarksEntry from './components/BulkMarksEntry';
import StandaloneCalorieTracker from './components/StandaloneCalorieTracker';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('dashboard');
  const [lang, setLang] = useState<Language>('en');
  const [students] = useState<Student[]>(INITIAL_STUDENTS);
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  
  const [logs, setLogs] = useState<DailyLog[]>(() => getFromLocal('shala_logs', []));
  const [assessments, setAssessments] = useState<Assessment[]>(() => getFromLocal('shala_assessments', []));
  const [events, setEvents] = useState<CalendarEvent[]>(() => getFromLocal('shala_events', INITIAL_EVENTS));

  useEffect(() => saveToLocal('shala_logs', logs), [logs]);
  useEffect(() => saveToLocal('shala_assessments', assessments), [assessments]);
  useEffect(() => saveToLocal('shala_events', events), [events]);

  const t = TRANSLATIONS[lang];

  const handleUpdateLog = (newLog: DailyLog) => {
    setLogs(prev => {
      const existing = prev.findIndex(l => l.studentId === newLog.studentId && l.date === newLog.date);
      if (existing !== -1) {
        const updated = [...prev];
        updated[existing] = newLog;
        return updated;
      }
      return [...prev, newLog];
    });
  };

  const handleBulkAttendanceSave = (newLogs: DailyLog[]) => {
    setLogs(prev => {
      const updated = [...prev];
      newLogs.forEach(nl => {
        const idx = updated.findIndex(l => l.studentId === nl.studentId && l.date === nl.date);
        if (idx !== -1) updated[idx] = nl;
        else updated.push(nl);
      });
      return updated;
    });
  };

  const handleBulkMarksSave = (newAsms: Omit<Assessment, 'id'>[]) => {
    const withIds = newAsms.map(a => ({ ...a, id: Math.random().toString() }));
    setAssessments(prev => [...prev, ...withIds]);
  };

  const handleAddAssessment = (asm: Omit<Assessment, 'id'>) => {
    const newAsm = { ...asm, id: Math.random().toString() };
    setAssessments(prev => [...prev, newAsm]);
  };

  const handleAddEvent = (evt: Omit<CalendarEvent, 'id'>) => {
    const newEvt = { ...evt, id: Math.random().toString() };
    setEvents(prev => [...prev, newEvt]);
  };

  const getAttendanceMap = () => {
    const today = new Date().toISOString().split('T')[0];
    const map: Record<string, AttendanceStatus> = {};
    logs.forEach(l => {
      if (l.date === today) map[l.studentId] = l.attendance;
    });
    return map;
  };

  const selectedStudent = students.find(s => s.id === selectedStudentId);

  const renderContent = () => {
    if (view === 'profile' && selectedStudent) {
      return (
        <StudentProfile 
          student={selectedStudent}
          logs={logs}
          assessments={assessments}
          lang={lang}
          onBack={() => setView('dashboard')}
          onUpdateLog={handleUpdateLog}
          onAddAssessment={handleAddAssessment}
        />
      );
    }

    if (view === 'calendar') return <CalendarModule events={events} lang={lang} onAddEvent={handleAddEvent} />;
    if (view === 'ai-tutor') return <AITutorModule lang={lang} />;
    if (view === 'attendance-bulk') return <BulkAttendance students={students} lang={lang} onSave={handleBulkAttendanceSave} onBack={() => setView('dashboard')} />;
    if (view === 'marks-entry') return <BulkMarksEntry students={students} lang={lang} onSave={handleBulkMarksSave} onBack={() => setView('dashboard')} />;
    if (view === 'calorie-scanner') return <StandaloneCalorieTracker lang={lang} />;

    if (view === 'reports') {
      return (
        <div className="p-6 pb-32">
          <h2 className="text-2xl font-black mb-6">{t.reports}</h2>
          <div className="bg-white rounded-[2rem] shadow-sm border border-slate-200 overflow-hidden">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-black text-[10px] tracking-wider">
                <tr>
                  <th className="px-6 py-4">Student</th>
                  <th className="px-6 py-4">Attendance</th>
                  <th className="px-6 py-4">Avg Score</th>
                  <th className="px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.map(s => {
                  const sLogs = logs.filter(l => l.studentId === s.id);
                  const sAsms = assessments.filter(a => a.studentId === s.id);
                  const attRate = sLogs.length ? Math.round((sLogs.filter(l => l.attendance === 'present').length / sLogs.length) * 100) : 0;
                  const avgScore = sAsms.length ? Math.round(sAsms.reduce((acc, a) => acc + (a.score/a.maxScore), 0) / sAsms.length * 100) : 0;
                  
                  return (
                    <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-bold">{lang === 'en' ? s.name : s.nameKn}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                           <div className="w-12 h-2 bg-slate-100 rounded-full overflow-hidden">
                             <div className="h-full bg-green-500" style={{ width: `${attRate}%` }}></div>
                           </div>
                           <span className="font-mono font-bold">{attRate}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono font-bold text-indigo-600">{avgScore}%</td>
                      <td className="px-6 py-4">
                        <button className="text-indigo-600 font-bold hover:underline">Export</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      );
    }

    // Dashboard
    return (
      <div className="animate-in fade-in duration-500 pb-32">
        <header className="p-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-black text-slate-800 tracking-tight">ShalaTracker</h1>
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Teacher Suite</p>
          </div>
          <button 
            onClick={() => setLang(lang === 'en' ? 'kn' : 'en')}
            className="bg-white px-4 py-2 rounded-full border border-slate-200 text-xs font-black shadow-sm active:scale-95 transition-all hover:bg-slate-50"
          >
            {lang === 'en' ? 'ಕನ್ನಡ' : 'English'}
          </button>
        </header>

        <div className="px-4 py-2">
           <div className="bg-indigo-600 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-3xl font-black mb-1">Teacher Dashboard</h2>
                <p className="text-indigo-100 text-sm opacity-80 mb-6">{new Date().toLocaleDateString(lang === 'en' ? 'en-IN' : 'kn-IN', { weekday: 'long', month: 'long', day: 'numeric' })}</p>
                <div className="grid grid-cols-2 gap-3">
                   <button onClick={() => setView('attendance-bulk')} className="bg-white text-indigo-900 px-4 py-3 rounded-2xl text-xs font-black transition-all shadow-lg active:scale-95">Daily Attendance</button>
                   <button onClick={() => setView('marks-entry')} className="bg-indigo-500 text-white px-4 py-3 rounded-2xl text-xs font-black border border-indigo-400 active:scale-95">Upload Marks</button>
                </div>
              </div>
              <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -mr-24 -mt-24 blur-3xl"></div>
           </div>
        </div>

        <StudentGrid 
          students={students} 
          lang={lang} 
          onSelect={(id) => { setSelectedStudentId(id); setView('profile'); }}
          attendanceMap={getAttendanceMap()}
        />

        <div className="p-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
            <h3 className="font-black text-slate-800 mb-4 flex items-center">
              <span className="mr-3 bg-indigo-100 p-2 rounded-xl text-xl">💡</span> Insights
            </h3>
            <div className="space-y-3">
              <div className="p-4 bg-indigo-50/50 text-indigo-700 rounded-2xl text-sm border border-indigo-100">
                <p className="font-bold">Weekly Performance</p>
                <p className="opacity-80">Class average has improved by 12% in Kannada this month.</p>
              </div>
              <div className="p-4 bg-emerald-50/50 text-emerald-700 rounded-2xl text-sm border border-emerald-100">
                <p className="font-bold">Nutrition Goal</p>
                <p className="opacity-80">Mid-day meal calorie tracking is 100% complete for this week.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto min-h-screen bg-slate-50 relative">
      {renderContent()}

      <nav className="fixed bottom-0 left-0 right-0 max-w-4xl mx-auto bg-white/90 backdrop-blur-xl border-t border-slate-200 h-24 px-4 flex items-center justify-between z-40 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
        <button onClick={() => setView('dashboard')} className={`flex-1 flex flex-col items-center space-y-1 transition-all ${view === 'dashboard' ? 'text-indigo-600 scale-110' : 'text-slate-300'}`}>
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" /></svg>
          <span className="text-[9px] font-black uppercase tracking-widest">{t.dashboard}</span>
        </button>
        <button onClick={() => setView('calendar')} className={`flex-1 flex flex-col items-center space-y-1 transition-all ${view === 'calendar' ? 'text-indigo-600 scale-110' : 'text-slate-300'}`}>
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zm0-12H5V6h14v2z" /></svg>
          <span className="text-[9px] font-black uppercase tracking-widest">{t.calendar}</span>
        </button>
        
        {/* Floating Center Button: Toggles AI Tutor or Dashboard */}
        <div className="flex-1 flex justify-center -mt-12">
           <div className="bg-white p-2 rounded-full shadow-2xl">
              <button 
                onClick={() => setView(view === 'ai-tutor' ? 'dashboard' : 'ai-tutor')}
                className={`w-16 h-16 rounded-full flex items-center justify-center text-white shadow-xl transition-all active:scale-90 ${view === 'ai-tutor' ? 'bg-slate-800' : 'bg-indigo-600 shadow-indigo-200'}`}
              >
                <span className="text-2xl">{view === 'ai-tutor' ? '🏠' : '🎓'}</span>
              </button>
           </div>
        </div>

        <button onClick={() => setView('calorie-scanner')} className={`flex-1 flex flex-col items-center space-y-1 transition-all ${view === 'calorie-scanner' ? 'text-emerald-600 scale-110' : 'text-slate-300'}`}>
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm5-3v8h2.5v8H21V2c-2.76 0-5 2.24-5 4z" /></svg>
          <span className="text-[9px] font-black uppercase tracking-widest">Meals</span>
        </button>
        <button onClick={() => setView('reports')} className={`flex-1 flex flex-col items-center space-y-1 transition-all ${view === 'reports' ? 'text-indigo-600 scale-110' : 'text-slate-300'}`}>
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14z" /></svg>
          <span className="text-[9px] font-black uppercase tracking-widest">{t.reports}</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
