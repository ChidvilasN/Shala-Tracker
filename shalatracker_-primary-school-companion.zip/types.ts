
export type Standard = 'Std 1' | 'Std 2' | 'Std 3' | 'Std 4' | 'Std 5' | 'Std 6' | 'Std 7';

export interface Student {
  id: string;
  name: string;
  nameKn: string;
  standard: Standard;
  rollNo: number;
  photo?: string;
}

export type AttendanceStatus = 'present' | 'absent' | 'late';

export interface DailyLog {
  id: string;
  studentId: string;
  date: string; // ISO string YYYY-MM-DD
  attendance: AttendanceStatus;
  homeworkDone: boolean;
  homeworkNote?: string;
  calories: number;
  mealItem?: string;
  mealPhoto?: string; // base64 photo
  learningNote?: string;
}

export type AssessmentType = 'Unit Test' | 'Monthly Test' | 'Mid-Term' | 'Annual';

export interface Assessment {
  id: string;
  studentId: string;
  date: string;
  type: AssessmentType;
  subject: string;
  score: number;
  maxScore: number;
}

export interface Competency {
  id: string;
  studentId: string;
  subject: string;
  skill: string;
  level: number; // 1-5
  color: 'green' | 'amber' | 'red';
}

export type EventType = 'holiday' | 'exam' | 'activity' | 'meeting' | 'celebration';

export interface CalendarEvent {
  id: string;
  titleEn: string;
  titleKn: string;
  type: EventType;
  date: string;
  notes?: string;
  recurrence?: 'none' | 'weekly' | 'monthly';
  notifyPriorDays: number;
}

export interface MenuItem {
  id: string;
  nameEn: string;
  nameKn: string;
  calories: number;
}

export type AppView = 'dashboard' | 'profile' | 'calendar' | 'ai-tutor' | 'reports' | 'attendance-bulk' | 'marks-entry' | 'calorie-scanner';
export type Language = 'en' | 'kn';
