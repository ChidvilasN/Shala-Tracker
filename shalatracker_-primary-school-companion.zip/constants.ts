
import { Student, MenuItem, CalendarEvent } from './types';

export const INITIAL_STUDENTS: Student[] = [
  { id: '1', name: 'Gautami', nameKn: 'ಗೌತಮಿ', standard: 'Std 1', rollNo: 1 },
  { id: '2', name: 'Gagana', nameKn: 'ಗಗನಾ', standard: 'Std 1', rollNo: 2 },
  { id: '3', name: 'Mohamad Arfarn', nameKn: 'ಮೊಹಮ್ಮದ್ ಅರ್ಫಾನ್', standard: 'Std 1', rollNo: 3 },
  { id: '4', name: 'Mohamad Jahid', nameKn: 'ಮೊಹಮ್ಮದ್ ಜಾಹಿದ್', standard: 'Std 1', rollNo: 4 },
  { id: '5', name: 'Chirayu', nameKn: 'ಚಿರಾಯು', standard: 'Std 2', rollNo: 5 },
  { id: '6', name: 'Pratham M', nameKn: 'ಪ್ರಥಮ್ ಎಂ', standard: 'Std 3', rollNo: 6 },
  { id: '7', name: 'Pruthvik M', nameKn: 'ಪೃಥ್ವಿಕ್ ಎಂ', standard: 'Std 4', rollNo: 7 },
  { id: '8', name: 'Pratham U', nameKn: 'ಪ್ರಥಮ್ ಯು', standard: 'Std 4', rollNo: 8 },
  { id: '9', name: 'Mohamad Adnan', nameKn: 'ಮೊಹಮ್ಮದ್ ಅದ್ನಾನ್', standard: 'Std 6', rollNo: 9 }
];

export const MEAL_MENU: MenuItem[] = [
  { id: '1', nameEn: 'Anna Sambhar', nameKn: 'ಅನ್ನ ಸಾಂಬಾರ್', calories: 350 },
  { id: '2', nameEn: 'Bisi Bele Bath', nameKn: 'ಬಿಸಿ ಬೇಳೆ ಬಾತ್', calories: 420 },
  { id: '3', nameEn: 'Puliyogare', nameKn: 'ಪುಳಿಯೋಗರೆ', calories: 380 },
  { id: '4', nameEn: 'Sweet Pongal', nameKn: 'ಸಿಹಿ ಪೊಂಗಲ್', calories: 450 }
];

export const INITIAL_EVENTS: CalendarEvent[] = [
  { id: 'e1', titleEn: 'Republic Day', titleKn: 'ಗಣರಾಜ್ಯೋತ್ಸವ', type: 'holiday', date: '2025-01-26', notifyPriorDays: 1 },
  { id: 'e2', titleEn: 'Unit Test 1', titleKn: 'ಘಟಕ ಪರೀಕ್ಷೆ ೧', type: 'exam', date: '2025-02-10', notifyPriorDays: 2 },
  { id: 'e3', titleEn: 'Parent Teacher Meeting', titleKn: 'ಪೋಷಕರ ಶಿಕ್ಷಕರ ಸಭೆ', type: 'meeting', date: '2025-02-15', notifyPriorDays: 3 }
];

export const SUBJECTS = ['Maths', 'Science', 'English', 'Kannada', 'EVS', 'Social Science'];

export const TRANSLATIONS = {
  en: {
    dashboard: 'Dashboard',
    calendar: 'Calendar',
    aiTutor: 'AI Tutor',
    reports: 'Reports',
    students: 'Students',
    attendance: 'Attendance',
    homework: 'Homework',
    meals: 'Meals',
    learnings: 'Learnings',
    assessments: 'Assessments',
    weakSpots: 'Weak Spots',
    addEntry: 'Add Daily Entry',
    save: 'Save',
    cancel: 'Cancel',
    present: 'Present',
    absent: 'Absent',
    late: 'Late',
    done: 'Done',
    notDone: 'Not Done',
    calories: 'Calories',
    standard: 'Standard',
    rollNo: 'Roll No',
    explain: 'Explain',
    conceptPrompt: 'Ask about a textbook concept...',
    back: 'Back',
    upcoming: 'Upcoming Events',
    takePhoto: 'Scan Meal',
    analyzing: 'Analyzing meal...',
    aiGeneratingVideo: 'AI Generating educational video...',
    markAttendance: 'Class Attendance',
    saveAll: 'Save All',
    uploadMarks: 'Upload Class Marks',
    focusSuggestions: 'Personalized Focus Areas',
    enterScore: 'Enter Score',
    maxScore: 'Max Score',
    subject: 'Subject',
    testType: 'Test Type'
  },
  kn: {
    dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    calendar: 'ಕ್ಯಾಲೆಂಡರ್',
    aiTutor: 'AI ಶಿಕ್ಷಕ',
    reports: 'ವರದಿಗಳು',
    students: 'ವಿದ್ಯಾರ್ಥಿಗಳು',
    attendance: 'ಹಾಜರಾತಿ',
    homework: 'ಮನೆಗೆಲಸ',
    meals: 'ಊಟ',
    learnings: 'ಕಲಿಕೆಗಳು',
    assessments: 'ಮೌಲ್ಯಮಾಪನಗಳು',
    weakSpots: 'ದುರ್ಬಲ ಅಂಶಗಳು',
    addEntry: 'ದೈನಂದಿನ ನಮೂದು ಸೇರಿಸಿ',
    save: 'ಉಳಿಸಿ',
    cancel: 'ರದ್ದುಮಾಡಿ',
    present: 'ಹಾಜರು',
    absent: 'ಗೈರುಹಾಜರು',
    late: 'ತಡವಾಗಿ',
    done: 'ಮುಗಿದಿದೆ',
    notDone: 'ಮುಗಿದಿಲ್ಲ',
    calories: 'ಕ್ಯಾಲೋರಿಗಳು',
    standard: 'ತರಗತಿ',
    rollNo: 'ರೋಲ್ ಸಂಖ್ಯೆ',
    explain: 'ವಿವರಿಸಿ',
    conceptPrompt: 'ಪಠ್ಯಪುಸ್ತಕದ ವಿಷಯದ ಬಗ್ಗೆ ಕೇಳಿ...',
    back: 'ಹಿಂದೆ',
    upcoming: 'ಮುಂಬರುವ ಕಾರ್ಯಕ್ರಮಗಳು',
    takePhoto: 'ಊಟವನ್ನು ಸ್ಕ್ಯಾನ್ ಮಾಡಿ',
    analyzing: 'ಊಟವನ್ನು ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...',
    aiGeneratingVideo: 'AI ಶೈಕ್ಷಣಿಕ ವೀಡಿಯೊವನ್ನು ತಯಾರಿಸುತ್ತಿದೆ...',
    markAttendance: 'ವರ್ಗದ ಹಾಜರಾತಿ',
    saveAll: 'ಎಲ್ಲವನ್ನೂ ಉಳಿಸಿ',
    uploadMarks: 'ಅಂಕಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
    focusSuggestions: 'ವೈಯಕ್ತಿಕ ಕಲಿಕೆಯ ಸಲಹೆಗಳು',
    enterScore: 'ಅಂಕವನ್ನು ನಮೂದಿಸಿ',
    maxScore: 'ಗರಿಷ್ಠ ಅಂಕ',
    subject: 'ವಿಷಯ',
    testType: 'ಪರೀಕ್ಷೆಯ ವಿಧ'
  }
};
